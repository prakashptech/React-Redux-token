import React, { useState } from 'react';
import axios from 'axios';
import './employeecreate.css';

const CreateEmployeeForm = () => {
  const [name, setName] = useState('');
  const [position, setPosition] = useState('');
  const [salary, setSalary] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const token = localStorage.getItem('token');
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const response = await axios.post('http://localhost:5000/api/employees', { name, position, salary }, {
        headers: {
          Authorization: `Bearer ${token}` // Include token in request headers
        }
      });
      console.log('Employee created:', response.data);
      window.location.href = '/employeeList';
      // Optionally, you can reset the form fields here
    } catch (error) {
      console.error('Error creating employee:', error);
      setError('Failed to create employee');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h2>Create Employee</h2>
      {token ? (
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="position">Position:</label>
            <input
              type="text"
              id="position"
              value={position}
              onChange={(e) => setPosition(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="salary">Salary:</label>
            <input
              type="text"
              id="salary"
              value={salary}
              onChange={(e) => setSalary(e.target.value)}
            />
          </div>
          <button type="submit" disabled={loading}>
            {loading ? 'Creating...' : 'Create'}
          </button>
          {error && <p className="error-message">{error}</p>}
        </form>
      ) : (
        <p>You need to log in to create an employee.</p>
      )}
    </div>
  );
};

export default CreateEmployeeForm;
